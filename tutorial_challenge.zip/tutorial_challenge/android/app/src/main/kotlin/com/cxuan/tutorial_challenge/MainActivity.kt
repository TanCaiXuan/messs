package com.cxuan.tutorial_challenge

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
